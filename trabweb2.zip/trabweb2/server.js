const { v4: uuidv4 } = require('uuid');
const express = require('express');
const { createClient } = require('@supabase/supabase-js');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const path = require('path');

const supabaseUrl = 'https://dahfetteubcledpnrybl.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRhaGZldHRldWJjbGVkcG5yeWJsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTcwNzQ2MzUsImV4cCI6MjA3MjY1MDYzNX0.8bU6zMMAz0m5qKaINCE2bYv32VPle5-JcQ_5qhS1yJw';
const supabase = createClient(supabaseUrl, supabaseKey);

const app = express();
const port = 3001;
const JWT_SECRET = 'dabliu2';


// CORS configuration - MAIS IMPORTANTE!
const corsOptions = {
    origin: ['http://localhost:3000', 'http://127.0.0.1:3000', 'http://localhost:3001', 'http://127.0.0.1:3001', '*'],
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization']
};

app.use(cors(corsOptions));

// Middleware adicional para garantir CORS
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    
    if (req.method === 'OPTIONS') {
        res.sendStatus(200);
    } else {
        next();
    }
});

app.use(express.json());

// Esta linha é a correção principal: o servidor agora serve arquivos estáticos de uma pasta 'public'
app.use(express.static(path.join(__dirname, 'public')));

  const notebookDatabase = {
    "Notebook Básico": [
        {
            nome: "Notebook ASUS VivoBook Go 15",
            imagem: "https://m.media-amazon.com/images/I/71TK+vh6JIL._AC_SX679_.jpg",
            link: "https://www.amazon.com.br/Notebook-ASUS-VivoBook-RYZEN-KeepOS/dp/B0CYW2N6TX?source=ps-sl-shoppingads-lpcontext&ref_=fplfs&psc=1&smid=A1ZZFT5FULY4LN ",
            preco: "R$ 2.378,00",
            specs: "AMD RYZEN 5 7520U, 8GB, 512GB SSD, KeepOS, Tela 15,6 FHD, Mixed Black - E1504FA-NJ732"
        },
        {
            nome: "Lenovo IdeaPad 1i",
            imagem: "https://p3-ofp.static.pub/fes/cms/2021/10/25/caqm6xeo57daq7nij26glvewaqvt02706786.png",
            link: "https://www.lenovo.com/br/outlet/pt/p/laptops/ideapad/ideapad-100/88ips101778/82x5x006br?orgRef=https%253A%252F%252Fwww.google.com%252F&srsltid=AfmBOopM5bH9fwHx8NErew_2huqSBPGTRnwQyujVngjm2RVPoGjOMqPfdX4",
            preco: "R$ 2.849,99",
            specs: "AMD Ryzen 5 7520U 8GB 512GB SSD Windows 11 Home 15,6 HD"
        }
    ],
    "Notebook Intermediário": [
        {
            nome: "Notebook Acer Nitro V15",
            imagem: "https://www.kabum.com.br/_next/image?url=https%3A%2F%2Fimages7.kabum.com.br%2Fprodutos%2Ffotos%2F904907%2Fnotebook-acer-nitro-v15-anv15-52-52xm-intel-core-i5-16gb-ram-512gb-ssd-rtx-4050-15-6-fhd-ips-165hz-linux-preto-nh-u1tal-002_1753963066_gg.jpg&w=1920&q=75",
            link: "https://www.kabum.com.br/produto/904907/notebook-acer-nitro-v15-anv15-52-52xm-intel-core-i5-16gb-ram-512gb-ssd-rtx-4050-15-6-fhd-ips-165hz-linux-preto-nh-u1tal-002?srsltid=AfmBOoovgROE_1J9BhFk1vf6-zowZLgtPPj5YiVL8zdbPgDa6CjtD9CpmRE",
            preco: "R$ 5.649,00",
            specs: "IIntel core I5, 16GB RAM, 512GB SSD, RTX 4050, 15.6 FHD, IPS, 165Hz, Linux, Preto - NH.U1TAL.002"
        },
        {
            nome: "Notebook Lenovo LOQ-e",
            imagem: "https://http2.mlstatic.com/D_NQ_NP_2X_703184-MLA82429441831_022025-F.webp",
            link: "https://www.mercadolivre.com.br/notebook-lenovo-loq-e-15iax9e-intel-core-i5-12450hx-16gb-512gb-ssd-rtx-3050-windows-11-156-83me0007br-luna-grey/p/MLB46018205#polycard_client=search-nordic&search_layout=grid&position=1&type=product&tracking_id=f9f45367-734b-4b42-9bf5-945cdbf96acf&wid=MLB5452592328&sid=search",
            preco: "R$ 5.199,00",
            specs: "Intel Core i5-12450hx 16gb 512gb Ssd Rtx 3050 Windows 11 15.6 - 83me0007br Luna Grey"
        }
    ],
    "Notebook Avançado": [
        {
            nome: "Notebook Asus Vivobook",
            imagem: "https://http2.mlstatic.com/D_NQ_NP_2X_687767-MLA82359272544_022025-F.webp",
            link: "https://www.mercadolivre.com.br/notebook-asus-vivobook-s14-core-ultra-7-32gb-1tb-ssd-w11/p/MLB46347719#reco_backend=item_decorator&reco_client=home_affiliate-profile&reco_item_pos=0&source=affiliate-profile&reco_backend_type=function&reco_id=2e8528ca-df74-4b8f-ae39-f767ffda5f35&tracking_id=f320afb2-7b22-459b-8226-1b8e4134ef9a&c_id=/home/card-featured/element&c_uid=694b6e48-256e-49df-8981-969cc3a387da",
            preco: "R$7.000,00",
            specs: "Intel Ultra 7 258V, Windows 11, 32 GB RAM, 2880×1800 px, sem tela tátil, com leitor de cartão."
        },
        {
            nome: "Notebook Gamer Rog Strix G16",
            imagem: "https://http2.mlstatic.com/D_NQ_NP_2X_642373-MLA86855310857_062025-F.webp",
            link: "https://www.mercadolivre.com.br/notebook-gamer-rog-strix-g16-g615jpr-nvidia-rtx-5070-intel-core-i9-14900hx-32gb-ram-1tb-ssd-windows-11-home-tela-16-240hz-led-cinza-s5001w/p/MLB51764304#reco_backend=item_decorator&reco_client=home_affiliate-profile&reco_item_pos=0&source=affiliate-profile&reco_backend_type=function&reco_id=aaceb8a6-320c-4d56-9479-059022174450&tracking_id=7420e9a7-a4dd-4f80-9990-dd2dcb96153a&c_id=/home/card-featured/element&c_uid=9115b954-5bc1-486f-ac7b-52ea48cf7a02",
            preco: "R$ 15.000,00",
            specs: "G615jpr Nvidia Rtx 5070 Intel Core I9 14900hx 32gb Ram 1tb Ssd Windows 11 Home Tela 16 240hz Led Cinza - S5001w"
        }
    ]
};

// --- ROTAS PARA O USUÁRIO COMUM ---
app.get('/questionario', async (req, res) => {
    try {
        const { data: perguntas, error } = await supabase
            .from('perguntas')
            .select('*, alternativas(*)');

        if (error) {
            console.error('Erro ao buscar perguntas:', error);
            return res.status(500).json({ error: error.message });
        }

        res.status(200).json(perguntas);
    } catch (err) {
        console.error('Erro no servidor:', err);
        res.status(500).json({ error: 'Erro interno do servidor.' });
    }
});

app.post('/processar-respostas', async (req, res) => {
    try {
        const { respostas } = req.body;
        if (!Array.isArray(respostas) || respostas.length === 0) {
            return res.status(400).json({ error: 'Envie ao menos uma resposta.' });
        }

        const idsAlternativas = respostas.map(r => r.alternativa_id);
        const { data: alternativas, error } = await supabase
            .from('alternativas')
            .select('id, pontuacao')
            .in('id', idsAlternativas);

        if (error) {
            console.error('Erro ao buscar pontuações das alternativas:', error);
            return res.status(500).json({ error: error.message });
        }

        const pontuacaoTotal = alternativas.reduce((sum, a) => sum + (a.pontuacao || 0), 0);

        const { count, error: countError } = await supabase
            .from('perguntas')
            .select('*', { count: 'exact', head: true });

        if (countError) {
            console.error('Erro ao contar o número de perguntas:', countError);
            return res.status(500).json({ error: countError.message });
        }

        const NUM_PERGUNTAS = count;
        console.log("Número de perguntas atuais:", NUM_PERGUNTAS);
        
        const pontuacaoMedia = NUM_PERGUNTAS > 0 ? pontuacaoTotal / NUM_PERGUNTAS : 0;

        const sessaoId = uuidv4();
        const linhas = idsAlternativas.map(id => ({ sessao_id: sessaoId, alternativa_id: id }));
        await supabase.from('respostas').insert(linhas);

        let recomendacao = "";
    if (pontuacaoMedia <= 30) { 
        recomendacao = "Notebook Básico";
    } else if (pontuacaoMedia <= 59) { 
        recomendacao = "Notebook Intermediário";
    } else {
        recomendacao = "Notebook Avançado";
    } 

        const notebooksRecomendados = notebookDatabase[recomendacao];
        
        res.json({
            pontuacaoTotal,
            pontuacaoMedia,
            recomendacao,
            notebooks: notebooksRecomendados
        });

    } catch (err) {
        console.error('Erro no servidor ao processar respostas:', err);
        res.status(500).json({ error: 'Erro interno do servidor.' });
    }
});
// --- ROTAS PARA ADMINISTRAÇÃO ---
const verificarToken = (req, res, next) => {
    console.log('=== VERIFICANDO TOKEN ===');
    console.log('Headers recebidos:', req.headers);
    
    const token = req.headers['authorization']?.split(' ')[1];
    console.log('Token extraído:', token);
    
    if (!token) {
        console.log('Token não fornecido');
        return res.status(401).json({ error: 'Acesso negado. Token não fornecido.' });
    }

    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        console.log('Token decodificado:', decoded);
        req.user = decoded;
        next();
    } catch (err) {
        console.log('Erro ao verificar token:', err.message);
        res.status(400).json({ error: 'Token inválido.' });
    }
};

app.post('/admin/login', async (req, res) => {
    const { email, senha } = req.body;

    try {
        const { data: admin, error } = await supabase
            .from('usuarios')
            .select('id, senha_hash')
            .eq('email', email)
            .single();

        if (error || !admin) {
            return res.status(401).json({ error: 'Email ou senha inválidos' });
        }

        const match = await bcrypt.compare(senha, admin.senha_hash);

        if (match) {
            const token = jwt.sign({ id: admin.id, perfil: 'admin' }, JWT_SECRET, { expiresIn: '1h' });
            res.status(200).json({ token });
        } else {
            res.status(401).json({ error: 'Email ou senha inválidos' });
        }
    } catch (err) {
        console.error('Erro no servidor durante o login:', err);
        res.status(500).json({ error: 'Erro interno do servidor.' });
    }
});


app.post('/admin/perguntas', verificarToken, async (req, res) => {
    try {
        const { texto, peso, alternativas } = req.body;

        const { data: pergunta, error: perguntaError } = await supabase
            .from('perguntas')
            .insert({ texto: texto, peso: peso })
            .select('id');

        if (perguntaError) {
            console.error('Erro ao inserir pergunta:', perguntaError);
            return res.status(500).json({ error: perguntaError.message });
        }

        const perguntaId = pergunta[0].id;

        const alternativasParaSalvar = alternativas.map(alt => ({
            pergunta_id: perguntaId,
            texto_alternativa: alt.texto,
            pontuacao: alt.pontuacao
        }));

        const { error: alternativasError } = await supabase
            .from('alternativas')
            .insert(alternativasParaSalvar);

        if (alternativasError) {
            console.error('Erro ao inserir alternativas:', alternativasError);
            return res.status(500).json({ error: alternativasError.message });
        }

        res.status(201).json({ message: "Pergunta e alternativas salvas com sucesso!" });

    } catch (err) {
        console.error('Erro no servidor:', err);
        res.status(500).json({ error: 'Erro interno do servidor.' });
    }
});


app.put('/admin/perguntas/:id', verificarToken, async (req, res) => {
    try {
        const { id } = req.params;
        const { texto, peso } = req.body;

        const { error } = await supabase
            .from('perguntas')
            .update({ texto: texto, peso: peso })
            .eq('id', id);

        if (error) {
            console.error('Erro ao editar pergunta:', error);
            return res.status(500).json({ error: error.message });
        }

        res.status(200).json({ message: "Pergunta editada com sucesso!" });

    } catch (err) {
        console.error('Erro no servidor:', err);
        res.status(500).json({ error: 'Erro interno do servidor.' });
    }
});


// Rota para deletar uma pergunta e seus dados relacionados
app.delete('/admin/perguntas/:id', verificarToken, async (req, res) => {
    console.log('=== DELETANDO PERGUNTA ===');
    console.log('ID da pergunta:', req.params.id);
    console.log('Usuário autenticado:', req.user);
    
    try {
        const { id } = req.params;

        // 1. Encontrar todas as alternativas relacionadas à pergunta
        console.log('1. Buscando alternativas da pergunta...');
        const { data: alternativas, error: altError } = await supabase
            .from('alternativas')
            .select('id')
            .eq('pergunta_id', id);

        if (altError) {
            console.error('Erro ao buscar alternativas:', altError);
            return res.status(500).json({ error: altError.message });
        }

        console.log('Alternativas encontradas:', alternativas);

        // 2. Apagar todas as respostas relacionadas a essas alternativas
        if (alternativas.length > 0) {
            console.log('2. Deletando respostas relacionadas...');
            const idsAlternativas = alternativas.map(alt => alt.id);
            const { error: respostasError } = await supabase
                .from('respostas')
                .delete()
                .in('alternativa_id', idsAlternativas);
            
            if (respostasError) {
                console.error('Erro ao deletar respostas:', respostasError);
                return res.status(500).json({ error: respostasError.message });
            }
            console.log('Respostas deletadas com sucesso');
        }

        // 3. O próprio Supabase já está configurado para apagar as alternativas quando a pergunta é apagada
        console.log('3. Deletando a pergunta...');
        const { error: perguntaError } = await supabase
            .from('perguntas')
            .delete()
            .eq('id', id);

        if (perguntaError) {
            console.error('Erro ao apagar pergunta:', perguntaError);
            return res.status(500).json({ error: perguntaError.message });
        }

        console.log('Pergunta deletada com sucesso');
        res.status(200).json({ message: "Pergunta e dados relacionados apagados com sucesso!" });

    } catch (err) {
        console.error('Erro no servidor:', err);
        res.status(500).json({ error: 'Erro interno do servidor.' });
    }
});


// Rota para editar uma alternativa específica
app.put('/admin/alternativas/:id', verificarToken, async (req, res) => {
    try {
        const { id } = req.params;
        const { texto, pontuacao } = req.body;

        const { error } = await supabase
            .from('alternativas')
            .update({
                texto_alternativa: texto,
                pontuacao: pontuacao
            })
            .eq('id', id);

        if (error) {
            console.error('Erro ao editar alternativa:', error);
            return res.status(500).json({ error: error.message });
        }

        res.status(200).json({ message: "Alternativa editada com sucesso!" });

    } catch (err) {
        console.error('Erro no servidor:', err);
        res.status(500).json({ error: 'Erro interno do servidor.' });
    }
});


// Rota para deletar uma alternativa específica
app.delete('/admin/alternativas/:id', verificarToken, async (req, res) => {
    console.log('=== DELETANDO ALTERNATIVA ===');
    console.log('ID da alternativa:', req.params.id);
    console.log('Usuário autenticado:', req.user);
    
    try {
        const { id } = req.params;

        // 1. Apagar todas as respostas que referenciam essa alternativa
        console.log('1. Deletando respostas relacionadas...');
        const { error: respostasError } = await supabase
            .from('respostas')
            .delete()
            .eq('alternativa_id', id);

        if (respostasError) {
            console.error('Erro ao deletar respostas:', respostasError);
            return res.status(500).json({ error: respostasError.message });
        }

        // 2. Apagar a alternativa depois de limpar as respostas
        console.log('2. Deletando a alternativa...');
        const { error } = await supabase
            .from('alternativas')
            .delete()
            .eq('id', id);

        if (error) {
            console.error('Erro ao apagar alternativa:', error);
            return res.status(500).json({ error: error.message });
        }

        console.log('Alternativa deletada com sucesso');
        res.status(200).json({ message: "Alternativa apagada com sucesso!" });

    } catch (err) {
        console.error('Erro no servidor:', err);
        res.status(500).json({ error: 'Erro interno do servidor.' });
    }
});

app.listen(port, () => {
    console.log(`Rodando em http://localhost:${port}`);
});